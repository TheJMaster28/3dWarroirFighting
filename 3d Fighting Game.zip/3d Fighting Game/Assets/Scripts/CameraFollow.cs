﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [SerializeField]
    private Vector3 offsetPostion;

    private Transform target;

    void Awake() {
        target = GameObject.FindGameObjectWithTag("Player").transform; 
    }


    void LateUpdate()
    {
        FollowPlayer();
    }

    void FollowPlayer() {

        transform.position = target.TransformPoint(offsetPostion);

        transform.rotation = target.rotation;

        
    }
}
